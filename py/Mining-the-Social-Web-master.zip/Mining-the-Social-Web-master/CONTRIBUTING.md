Sept 2013

This repository provides the latest updated/bug-fixed examples for _Mining the Social Web, 1st Edition_ and is guaranteed to contain newer code than what is in the version of the book that you are reading. 

Please do not log issues for the [2nd Edition](https://github.com/ptwobrussell/Mining-the-Social-Web-2nd-Edition) of the book in this repository. Log them in its repository instead.

Given the imminent release of the 2nd Edition in Sept 2013 and all of the work that has gone into creating a superior learning experience and codebase for the 2nd Edition after several years of reader feedback, all consumers of the code in this repository are highly encouraged to migrate to the [new repository for the 2nd Edition](https://github.com/ptwobrussell/Mining-the-Social-Web-2nd-Edition) by the end of 2013. (It is superior in nearly every way, and you'll be glad that you migrated and never looked back.)

It is unlikely that this repository will continue to be maintained after the end of 2013.

Thank you,<br>
Matthew A. Russell
