import json
import sys

fh = open('miserables.json', 'r')
xx = json.loads(fh.read())
